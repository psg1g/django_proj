from django.shortcuts import render,redirect
from django.views.generic import TemplateView, CreateView, ListView, DetailView, UpdateView, DeleteView 
from .models import *
from .models import Category 
from .forms import *
from django.urls import reverse_lazy
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login, logout
from django.contrib.auth.models import User

# Create your views here.
def index(request):
    return render(request,'index.html')



class CategoryCreateView(CreateView):
    model = Category
    form_class = CategoryForm  # или ModelForm
    template_name = 'create_category.html'
    success_url = '/categories'

class CategoryListView(ListView):
    form_class = CategoryForm
    model = Category
    template_name = 'categories.html'
    context_object_name = 'categories'

class CategoryDetailView(DetailView):
    model = Category
    template_name = 'category_detail.html'  # путь к шаблону
    context_object_name = 'category'  # имя переменной в шаблоне
    pk_url_kwarg = 'pk'  # имя параметра в URL (по умолчанию 'pk')

class CategoryUpdateView(UpdateView):
    model = Category
    fields = ['name', 'description']  # Какие поля можно редактировать
    template_name = 'category_update.html'
    context_object_name = 'category'
    success_url = reverse_lazy('categories')  # Куда перенаправлять после сохранения
    
    def form_valid(self, form):
        messages.success(self.request, 'Категория успешно обновлена!')
        return super().form_valid(form)

class CategoryDeleteView(DeleteView):
    model = Category
    template_name = 'category_delete.html'
    context_object_name = 'category'
    success_url = reverse_lazy('categories')
    
    def delete(self, request, *args, **kwargs):
        messages.success(self.request, 'Категория успешно удалена!')
        return super().delete(request, *args, **kwargs)

# ===== РЕГИСТРАЦИЯ (КЛАССОВОЕ ПРЕДСТАВЛЕНИЕ) =====
class RegisterView(CreateView):
    model = User
    form_class = UserCreationForm
    template_name = 'register.html'
    success_url = reverse_lazy('login')
    
    def form_valid(self, form):
        # Сохраняем пользователя
        user = form.save()
        messages.success(self.request, f'Пользователь {user.username} успешно зарегистрирован! Теперь вы можете войти.')
        return super().form_valid(form)
    
    def form_invalid(self, form):
        for error in form.errors.values():
            messages.error(self.request, error)
        return super().form_invalid(form)

def custom_logout(request):
    logout(request)
    messages.info(request, 'Вы успешно вышли из системы!')
    return redirect('index')