from django.urls import path
from django.views.generic import TemplateView
from .views import *
from . import views
from django.contrib.auth.views import LoginView, LogoutView

urlpatterns = [
    path('', TemplateView.as_view(template_name='index.html'), name='index'),
    path('contacts', TemplateView.as_view(template_name='contacts.html'), name='contacts'),
    path('create_category', CategoryCreateView.as_view(), name='create_category'),
    path('categories', CategoryListView.as_view(), name='categories'),
    path('category/<int:pk>/', views.CategoryDetailView.as_view(), name='category_detail'),
    path('category/<int:pk>/update/', views.CategoryUpdateView.as_view(), name='category_update'),
    path('category/<int:pk>/delete/', views.CategoryDeleteView.as_view(), name='category_delete'),
    # ===== АВТОРИЗАЦИЯ =====
    path('register/', views.RegisterView.as_view(), name='register'),  # Регистрация
    path('login/', LoginView.as_view(template_name='login.html'), name='login'),  # Вход
    path('logout/', views.custom_logout, name='logout'),  # Замени на кастомный
]

